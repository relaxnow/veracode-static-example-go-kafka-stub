# go-kafka-mock-example

Use this to get Kafka up and running on minikube: https://technology.amis.nl/platform/kubernetes/running-apache-kafka-on-minikube/