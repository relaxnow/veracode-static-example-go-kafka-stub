# confluent-kafka-go-veracode-stub
